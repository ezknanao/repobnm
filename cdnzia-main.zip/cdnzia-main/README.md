# CDN files for animezia.com repo

Fork repo and deploy on netlify, cloudflare pages, vercel or cyclic.
